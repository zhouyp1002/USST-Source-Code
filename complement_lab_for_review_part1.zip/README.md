This code is a supplementary experiment. It includes the implementation of local differential privacy (LDP) and the NCF method with differential privacy noise.

'./LDP' is the code of SVD with differential privacy noise and LDP. The result is displayed in Figure 3 in the paper.

'./NCF_DP' is the code of NCF with differential privacy noise. The result is displayed in Figure 5 in the paper.

