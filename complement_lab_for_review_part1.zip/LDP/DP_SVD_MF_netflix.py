#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Apr 28 15:28:11 2021

@author: xiandai
"""#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Apr 23 14:35:38 2021

@author: xiandai
"""

import pandas as pd
import numpy as np

import time

def SGD_MF(trainset,row,col,epsilon):
	#超参数
    k =  20           #隐因子矩阵的维数
    deta = 2e-3    
    lamda = 0.1       #正则化系数
    iteration = 500   #迭代次数

    P = np.random.rand(row,k);
    Q = np.random.rand(k,col);

    #miu = 0
    miu = trainset['rating'].mean()

    time_start=time.time()
    
    for it in range(iteration):
        gradient_P = np.zeros((row,k))
        gradient_Q = np.zeros((k,col))
        cnt_Q = np.zeros(col)
        train_RMSE = 0
        
        idx_list = train_set.index.unique()
        for idx in idx_list:
            i = int(idx)-1
            j = np.array(trainset.loc[idx,'item']) - 1
            j = j.astype(int)
            ori_rating = np.array(trainset.loc[idx,'rating'])
            #pred_rating = np.dot(P[i,:],Q[:,j])
            pred_rating = np.dot(P[i,:],Q[:,j]) + miu
            err_rating = ori_rating - pred_rating
            train_RMSE += np.sum(err_rating**2 )
            
            if type(j)== np.ndarray:
                pred_rating[pred_rating>5] = 5
                pred_rating[pred_rating<1] = 1
            else:
                pred_rating = min(pred_rating,5)
                pred_rating = max(pred_rating,1)
                
            gradient_P[i,:] += np.sum( (err_rating*Q[:,j]).T, axis=0)
            if type(j)== np.ndarray:
                num_j = len(j)
            else:
                num_j = 1
            P[i,:] = P[i,:] + deta*gradient_P[i,:]/num_j - lamda* P[i,:]
            
            tmp_P = np.tile(P[i,:],(num_j,1))
            err_rating = np.tile(err_rating,(k,1))
            
            if type(j)== np.ndarray:
                gradient_Q[:,j] += err_rating*(tmp_P.T)
            else:
                gradient_Q[:,j] += (err_rating*(tmp_P.T)).reshape((-1))
            cnt_Q[j] += num_j

        for j in range(col):
            if cnt_Q[j] != 0:
                Q[:,j] = Q[:,j] + deta*gradient_Q[:,j]/cnt_Q[j] - lamda*Q[:,j]
        
        train_RMSE = np.sqrt(train_RMSE/trainset.shape[0])
        
        #if it%10 == 0:
        #if it%1 == 0:
        #    print('train process: %.2f %%'%(it* 100/iteration))
    
    time_end=time.time()
    print('time cost',time_end-time_start,'s')
    
    print("epsilon: ",epsilon,' train RMSE: ',train_RMSE)
    
    return P,Q,miu


#%%   
#for epsilon in [0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1]: 
for epsilon in [0.1,0.2,0.4,0.8,1.6,3.2,6.4]: 
    # read data
    train_set = pd.read_csv('./data/netflix_train.txt',header=None,sep='\t', names=['user','item','rating'])
    test_set = pd.read_csv('./data/netflix_test.txt',header=None,sep='\t', names=['user','item','rating'])
    train_set.index = train_set['user']
    test_set.index = test_set['user']
    train_row,train_col = train_set.shape
#%%
# train MF

#for epsilon in range(0,1,0.1):  

    # give noise to train_set
    #epsilon = 0.1
    #delta_f = 5/train_row
    delta_f = 4
    b = delta_f/epsilon
    #b = 0.35
    #laplace_noise = np.random.laplace(0, b, train_row)
    laplace_noise = np.random.laplace(0, b, train_row)
    train_set['rating'] = train_set['rating'] + laplace_noise

    train_set['rating'] = train_set['rating'].apply(lambda x: min(x,5))
    train_set['rating'] = train_set['rating'].apply(lambda x: max(x,1))
    
    # train
    row = max(train_set['user'].max(),test_set['user'].max())
    col = max(train_set['item'].max(),test_set['item'].max())
    P,Q,miu = SGD_MF(train_set,row,col,epsilon)


    #%%
    # test
    test_RMSE = 0
    idx_list = test_set.index.unique()
    for idx in idx_list:
        i = int(idx)-1
        j = np.array(test_set.loc[idx,'item']) - 1
        j = j.astype(int)
        ori_rating = np.array(test_set.loc[idx,'rating'])
        #pred_rating = np.dot(P[i,:],Q[:,j])
        pred_rating = np.dot(P[i,:],Q[:,j]) + miu
        
        if type(j)== np.ndarray:
                pred_rating[pred_rating>5] = 5
                pred_rating[pred_rating<1] = 1
        else:
            pred_rating = min(pred_rating,5)
            pred_rating = max(pred_rating,1)
                
        err_rating = ori_rating - pred_rating
        test_RMSE += np.sum(err_rating**2)
    test_RMSE = np.sqrt(test_RMSE/test_set.shape[0])
    print("epsilon: ",epsilon,' test RMSE:',test_RMSE)



