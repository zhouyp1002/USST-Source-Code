#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Apr 25 01:35:22 2021

@author: xiandai
"""

import pandas as pd
import numpy as np

dataset = pd.read_csv('./data/ml_100k.txt',header=None,sep='\t', names=['user','item','rating'])
#dataset = pd.read_csv('./data/netflix.txt',header=None,sep='\t', names=['user','item','rating'])
dataset_size = dataset.shape[0]
shuffle_list = np.random.permutation(dataset_size)

ratio = 0.8;
train_idx = shuffle_list[:int(dataset_size*ratio)]
test_idx = shuffle_list[int(dataset_size*ratio):]
trainset = dataset.iloc[train_idx,:]
testset = dataset.iloc[test_idx,:]

trainset.to_csv('./data/train.txt',sep='\t') 
testset.to_csv('./data/test.txt',sep='\t') 

#trainset.to_csv('./data/ml_100k_train.txt',sep='\t') 
#testset.to_csv('./data/ml_100k_test.txt',sep='\t') 

#trainset.to_csv('./data/netflix_train.txt',sep='\t') 
#testset.to_csv('./data/netflix_test.txt',sep='\t') 