#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Apr 23 14:35:38 2021

@author: xiandai
"""

import pandas as pd
import numpy as np

import time

#file = None
q = 50
phai = []
phai_inv = []
    
def LDP_SGD_MF(trainset,row,col,epsilon=2):    
    
	#超参数
    k =  20           #隐因子矩阵的维数
    
    deta = 1e-2    
    #lamda = 1e-2       #正则化系数
    #iteration = 60      #迭代次数
    lamda = 0.01
    iteration = 500

    sample_rate = 1  # indeed sample_rate * sample_rate
    
    #exp_term = np.exp(epsilon/iteration)
    exp_term = np.exp(epsilon)
    
    P = np.random.rand(row,k);
    Q = np.random.rand(k,col);
    
    miu = 0
    #miu = trainset['rating'].mean()

    time_start=time.time()
    
    for it in range(iteration):
        gradient_P = np.zeros((row,k))
        #gradient_Q = np.zeros((k,col))
        gradient_Q = np.zeros((k,q))
        
        train_RMSE = 0
        
        #deta = 1/(it+1)
      
        idx_list = trainset.index.unique()
        for idx in idx_list:
            
            local_Q = np.zeros((k,col))  # X
            #perturbate_sample_local_Q = np.zeros((k,col))
            perturbate_sample_local_Q = np.zeros((k,q))
            
            i = int(idx)-1
            j = np.array(trainset.loc[idx,'item']) - 1
            ori_rating = np.array(trainset.loc[idx,'rating'])
            #pred_rating = np.dot(P[i,:],Q[:,j])
            pred_rating = np.dot(P[i,:],Q[:,j]) + miu
            
            if type(j)== np.ndarray:
                pred_rating[pred_rating>5] = 5
                pred_rating[pred_rating<1] = 1
            else:
                pred_rating = min(pred_rating,5)
                pred_rating = max(pred_rating,1)
                
            err_rating = ori_rating - pred_rating
            train_RMSE += np.sum(err_rating**2 )
          
            if type(j)== np.ndarray:
                num_j = len(j)
            else:
                num_j = 1
            tmp_P = np.tile(P[i,:],(num_j,1))
            
            if num_j==1:
                local_Q[:,j] += (err_rating*tmp_P.T).reshape((-1))
            else:
                local_Q[:,j] += err_rating*tmp_P.T
            
            
            local_Q[:,j] = local_Q[:,j] * 2
            
            
            
            local_Q = np.dot(phai,local_Q.T).T
            
            # Perturbation
            # sample j,l
            
            #sample_j_size = int(col*sample_rate)
            
            sample_j_size = int(q*sample_rate)
            sample_j_size = max(1,sample_j_size)
            sample_l_size = int(k*sample_rate)
            sample_l_size = max(1,sample_l_size)
            #sample_j_size = 1
            #sample_l_size = 1
            #sample_j = np.random.permutation(col)[:sample_j_size]
            sample_j = np.random.permutation(q)[:sample_j_size]
            sample_l = np.random.permutation(k)[:sample_l_size]
            
            # project to -1, 1
            
            one_matrix = np.ones((sample_l_size,sample_j_size))
            #aux_matrix = local_Q[sample_l,:][:,sample_j]
            aux_matrix = local_Q[sample_l,:][:,sample_j]
            
            aux_matrix[aux_matrix > one_matrix] = 1
            one_matrix = one_matrix * -1
            aux_matrix[aux_matrix < one_matrix] = -1
            
            
            '''
            min_Q = local_Q.min()
            interval_Q = local_Q.max() - min_Q
            avg_Q = local_Q.mean()
            aux_matrix = local_Q[sample_l,:][:,sample_j]
            aux_matrix = (aux_matrix - min_Q)/interval_Q * 2 - 1
            '''
            
            # Perturbate
            beta = 1
            #prob_thr = (aux_matrix * (exp_term-beta) + exp_term + beta )/(2*(exp_term+beta))
            prob_thr = (aux_matrix * (exp_term-beta) + exp_term + beta )/(2*(exp_term+beta))
            prob_rand = np.random.rand(sample_l_size,sample_j_size)
            prob_rand[prob_rand >= prob_thr] = 1
            prob_rand[prob_rand < prob_thr] = -1
            
            '''
            if idx == idx_list[0]:
                print('aux_matrix')
                print(aux_matrix[0])
                print('prob_thr')
                print(prob_thr[0])
            '''
            
            #
            #prob_rand = prob_rand * (k*col*(exp_term+beta))/(exp_term-beta)    
            prob_rand = prob_rand * (k*q*(exp_term+beta))/(exp_term-beta)    
            
            prob_rand = prob_rand * -1
            #prob_rand = (prob_rand + 1)/2 *interval_Q
            
            perturbate_sample_local_Q[sample_l,:][:,sample_j] = prob_rand
            
            # sum
            gradient_Q += perturbate_sample_local_Q
            
            
        train_RMSE = np.sqrt(train_RMSE/trainset.shape[0])
        gradient_Q = gradient_Q/len(idx_list)
        #Q = Q + deta*gradient_Q - lamda*Q
            
        if num_j==1:
            Q += deta* ( np.dot(phai_inv , gradient_Q.T).T ) - lamda*Q
        else:
            Q += deta* ( np.dot(phai_inv , gradient_Q.T).T )  - lamda*Q
                
        for idx in idx_list:                       
            i = int(idx)-1
            j = np.array(trainset.loc[idx,'item']) - 1
            ori_rating = np.array(trainset.loc[idx,'rating'])
            #pred_rating = np.dot(P[i,:],Q[:,j])
            pred_rating = np.dot(P[i,:],Q[:,j]) + miu
            err_rating = ori_rating - pred_rating
            
            if type(j)== np.ndarray:
                num_j = len(j)
            else:
                num_j = 1
            gradient_P[i,:] += np.sum( (err_rating*Q[:,j]).T, axis=0)
            P[i,:] = P[i,:] + deta*gradient_P[i,:]/num_j - lamda* P[i,:]    
           
            
        
        if it%10 == 0:
        #if it%1 == 0:
            print('train process: %.2f %%'%(it* 100/iteration))
    
    time_end=time.time()
    #print('time cost',time_end-time_start,'s')
    
    print("epsilon: ",epsilon," train RMSE: ",train_RMSE)
    
    return P,Q,miu


#%%    
if __name__ == '__main__':       
    
    print("begin")
    
    #prefix = 'exp01_'
    #filename = prefix+"movielens_LDP.txt"
    #file = open(filename,'w')
    
    # read data
    train_set = pd.read_csv('./data/netflix_train.txt',header=None,sep='\t', names=['user','item','rating'])
    test_set = pd.read_csv('./data/netflix_test.txt',header=None,sep='\t', names=['user','item','rating'])
    train_set.index = train_set['user']
    test_set.index = test_set['user']
    train_row,train_col = train_set.shape
    #%%
    # train MF
    
    # give noise to train_set
    #b = 0.35
    #miu = 0
    #laplace_noise = np.random.laplace(miu, b, train_row)
    #train_set['rating'] = train_set['rating'] + laplace_noise
    
    # train
    row = max(train_set['user'].max(),test_set['user'].max())
    col = max(train_set['item'].max(),test_set['item'].max())
    #q = 2700
    #random_matrix = np.random.normal(0,1/np.sqrt(q),(q,col))
    #P,Q,miu = LDP_SGD_MF(train_set,row,col,random_matrix,q)
    
    
    #for epsilon in [0.1,0.2,0.4,0.8,1.6]:  
    #for epsilon in [0.01,0.1,1,10]:  
    #for epsilon in [0.2,0.4,0.1,0.8,1.6]:  
    
    phai = np.random.rand(q,col)
    phai_inv = np.linalg.pinv( phai )
    #for epsilon in [0.05, 0.1,0.2,0.4,0.8]: 
    #for epsilon in [0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1]: 
    #for epsilon in [0.1,0.2,0.4,0.8,1.6,3.2,6.4]: 
    for epsilon in [6.4]: 
        P,Q,miu = LDP_SGD_MF(train_set,row,col,epsilon)
    
    
        #%%
        # test
        test_RMSE = 0
        idx_list = test_set.index.unique()
        for idx in idx_list:
            i = int(idx)-1
            j = np.array(test_set.loc[idx,'item']) - 1
            ori_rating = np.array(test_set.loc[idx,'rating'])
            #pred_rating = np.dot(P[i,:],Q[:,j])
            pred_rating = np.dot(P[i,:],Q[:,j]) + miu
            
            if type(j)== np.ndarray:
                pred_rating[pred_rating>5] = 5
                pred_rating[pred_rating<1] = 1
            else:
                pred_rating = min(pred_rating,5)
                pred_rating = max(pred_rating,1)
                
            err_rating = ori_rating - pred_rating
            test_RMSE += np.sum(err_rating**2)
        test_RMSE = np.sqrt(test_RMSE/test_set.shape[0])
        print("epsilon: ",epsilon,' test RMSE:',test_RMSE)

    print("finish")
    #file.close()
    