#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Apr 23 14:35:38 2021

@author: xiandai
"""

import pandas as pd
import numpy as np

def SGD_MF(trainset,row,col):
	#超参数
    k =  20           #隐因子矩阵的维数
    
  
    deta = 2e-3    
    lamda = 0.1       #正则化系数
    iteration = 500   #迭代次数

    P = np.random.rand(row,k);
    Q = np.random.rand(k,col);

    #miu = 0
    miu = trainset['rating'].mean()

    for it in range(iteration):
        gradient_P = np.zeros((row,k))
        gradient_Q = np.zeros((k,col))
        cnt_Q = np.zeros(col)
        train_RMSE = 0


        '''
        # method 1
        for cnt in range(trainset.shape[0]):
            i,j,ori_rating = trainset.iloc[cnt,:]
            i = int(i)-1
            j = int(j)-1
            pred_rating = np.dot(P[i,:],Q[:,j]) + miu
            err_rating = ori_rating - pred_rating
            train_RMSE += np.sum(err_rating**2 )
            
            P[i,:] = P[i,:] + deta*(err_rating*Q[:,j].T - lamda* P[i,:])
            Q[:,j] = Q[:,j] + deta*(err_rating*P[i,:].T - lamda* Q[:,j]) 
        '''
        
        idx_list = train_set.index.unique()
        for idx in idx_list:
            i = int(idx)-1
            j = np.array(trainset.loc[idx,'item']) - 1
            ori_rating = np.array(trainset.loc[idx,'rating'])
            #pred_rating = np.dot(P[i,:],Q[:,j])
            pred_rating = np.dot(P[i,:],Q[:,j]) + miu
            err_rating = ori_rating - pred_rating
            train_RMSE += np.sum(err_rating**2 )
            
            gradient_P[i,:] += np.sum( (err_rating*Q[:,j]).T, axis=0)
            num_j = len(j)
            P[i,:] = P[i,:] + deta*gradient_P[i,:]/num_j - lamda* P[i,:]
            
            tmp_P = np.tile(P[i,:],(num_j,1))
            gradient_Q[:,j] += err_rating*tmp_P.T
            cnt_Q[j] += num_j

        for j in range(col):
            if cnt_Q[j] != 0:
                Q[:,j] = Q[:,j] + deta*gradient_Q[:,j]/cnt_Q[j] - lamda*Q[:,j]
        #'''
        
        train_RMSE = np.sqrt(train_RMSE/trainset.shape[0])
        
        #if it%10 == 0:
        if it%20 == 0:
            print('train process: %.2f %%'%(it* 100/iteration))
        
    
    print("train RMSE: ",train_RMSE)
    
    return P,Q,miu


#%%           
# read data
train_set = pd.read_csv('./data/ml_100k_train.txt',header=None,sep='\t', names=['user','item','rating'])
test_set = pd.read_csv('./data/ml_100k_test.txt',header=None,sep='\t', names=['user','item','rating'])
train_set.index = train_set['user']
test_set.index = test_set['user']
train_row,train_col = train_set.shape
#%%
# train MF

# give noise to train_set
b = 0.35
miu = 0
laplace_noise = np.random.laplace(miu, b, train_row)
#train_set['rating'] = train_set['rating'] + laplace_noise

# train
row = max(train_set['user'].max(),test_set['user'].max())
col = max(train_set['item'].max(),test_set['item'].max())
P,Q,miu = SGD_MF(train_set,row,col)


#%%
# test


test_RMSE = 0
idx_list = test_set.index.unique()
for idx in idx_list:
    i = int(idx)-1
    j = np.array(test_set.loc[idx,'item']) - 1
    ori_rating = np.array(test_set.loc[idx,'rating'])
    #pred_rating = np.dot(P[i,:],Q[:,j])
    pred_rating = np.dot(P[i,:],Q[:,j]) + miu
    err_rating = ori_rating - pred_rating
    test_RMSE += np.sum(err_rating**2)
test_RMSE = np.sqrt(test_RMSE/test_set.shape[0])
print('test RMSE:',test_RMSE)

'''
test_num = test_set.shape[0];
ori = np.zeros(test_num);
pred = np.zeros(test_num);
for cnt in range(test_num):
    
    if cnt%1000 == 0:
        print('test process: %.2f %%'%(cnt* 100/test_num))    
    
    user,item,ori_score = test_set.iloc[cnt,:]
    user = int(user)-1
    item = int(item)-1
    pred_MF_score =  np.dot(P[user,:],Q[:,item]) + miu
    
    if pred_MF_score > 5:
        pred_MF_score = 5
    elif pred_MF_score < 1:
        pred_MF_score = 1

    ori[cnt] = ori_score;
    pred[cnt] = pred_MF_score;    

RMSE  = np.sqrt(np.dot((ori-pred),(ori-pred))/test_num);   
print('test RMSE:',RMSE)
'''


