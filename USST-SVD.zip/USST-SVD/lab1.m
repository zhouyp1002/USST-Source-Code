
for iter = 1:10
    dataset_name = 'ml_100k';
    %dataset_name = 'netflix';
    
    split_data(dataset_name);

    fid=fopen('file_lab1_movielens.txt','a+');
    %fid=fopen('file_lab1_netflix.txt','a+');
    
    temp = strcat('------------ iter: ',num2str(iter),'------------ \n');
    fprintf(fid,temp);


cd './SVD'
%ls 
    %{
    %%
    % differential privacy
    for k = 0.1:0.1:2
        temp = strcat('MF sigma:  ',num2str(k));        
        disp(temp);
        fprintf(fid,temp,'\t');
        
        [RMSE,~,~]  = MF_lab(dataset_name,k)
          
        temp = strcat('DPMF RMSE:  ',num2str(RMSE));        
        disp(temp);
        fprintf(fid,temp,'\n');
    end
    %

    %}
    %% 
    % pure MF     
    [RMSE,~,~]  = MF_lab(dataset_name)
    temp = strcat('MF RMSE:  ', num2str(RMSE));
    disp(temp);
    fprintf(fid,temp,'\n');
    %   

    %
    %%
    sel = ["random","user_base","item_base","mixed"];
    %sam_point = [0.0025,0.005,0.01,0.02,0.04,0.08,0.16,0.32,0.64,1];
    %sam_point =  0.02:0.02:0.3;
    sam_point = [0.2];
    %para_mix = 1:10;
    %para_mix = 5;

    for i = 1:4      
        temp = strcat('sample-mathod: ',sel(i));
        disp(temp); 
        fprintf(fid,temp,' \n');

        for j = 1:length(sam_point)
            ratio = sam_point(j);

            temp = strcat('ratio:  ',num2str(ratio));
            disp(temp);
            fprintf(fid,temp,'\t');

            %for k = 1:length(para_mix)

                [rmse] = PPRS(dataset_name,ratio,sel(i),5);
                %[rmse] = PPRS(dataset_name,ratio,sel(i),para_mix(k));
                
                %temp = strcat('mix_parameter:  ',num2str(para_mix(k)));
                %disp(temp);
                %fprintf(fid,temp,'\t');
                
                temp = strcat('rmse:  ',num2str(rmse));
                disp(temp);
                fprintf(fid,temp,'\n');
            %end

        end

    end
    %

    %
    %%
    [RMSE] = SP(dataset_name)
    temp = strcat('SP RMSE:  ', num2str(RMSE));
    disp(temp);
    fprintf(fid,temp,'\n');
    %
    
    %
    %%
    
    cd '../IBCF'
    %cd './IBCF'
    %ls 
    [RMSE,~,~] = IBCF_lab(dataset_name)
    disp(['IBCF RMSE:  ',num2str(RMSE)]);

    fprintf(fid,'IBCF rmse:  ' );
    fprintf(fid,num2str(RMSE) );
    fprintf(fid,'\n' );

    %

cd ..

end

fprintf(fid,'successful finish! ' );

