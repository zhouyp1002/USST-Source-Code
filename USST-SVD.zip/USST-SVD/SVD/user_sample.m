

% gamma is need only when selection is 'mixed'
function [sam_user,pri_user] = user_sample(R,sam_num,selection,gamma)
    sam_user = [];
    pri_user = [];
    
    if strcmp(selection,'random')
         [sam_user,pri_user] = random_sel(R,sam_num);
      
    elseif strcmp(selection,'user_base')
        [sam_user,pri_user] = user_base(R,sam_num);
        
    elseif strcmp(selection,'item_base')
        [sam_user,pri_user] = item_base(R,sam_num);
        
    elseif strcmp(selection,'mixed')
        [sam_user,pri_user] = mixed(R,sam_num,gamma);
    
    end

end

function  [sam_user,pri_user] = random_sel(R,sam_num)
    m = size(R,1);
    perm = randperm(m);
    sam_user = perm(1:sam_num);
    pri_user = perm(sam_num+1:m);
end

function [sam_user,pri_user] = user_base(R,sam_num)
    rate_num = sum(R>0,2);
    [~,idx] = sort(rate_num,'descend');
    sam_user = idx(1:sam_num);
    pri_user = idx(sam_num+1:length(idx));
end

function [sam_user,pri_user] = item_base(R,sam_num)
    rate_num = sum(R>0,2);
    [~,idx] = sort(rate_num,'descend');
    row = size(R,1);
    
    rated_set = [];
    sam_user = [];
    pri_user = [];
    sel = zeros(row,1);
    
    %first_loop    
    for i = 1:row
        rate_idx = find( R(idx(i),:) >0 );       
        u_ = union(rated_set,rate_idx);
        
        if length(u_) > length(rated_set)
            rated_set = u_;
            sel(i) = 1;
            sam_num = sam_num - 1;
        end
        
        if sam_num ==0
           sam_user  = idx(sel>0);
           pri_user = idx(sel==0);
           return;
        end
    end
    
     %second_loop    
     %need confirm next step
    for i = 1:row    
        % could be improved to speed up
        if sel(i) == 0
            sel(i) = 1;
            sam_num = sam_num - 1;
        end
        
        if sam_num ==0
           sam_user  = idx(sel>0);
           pri_user = idx(sel==0);
           return;
        end
    end

end

function [sam_user,pri_user] = mixed(R,sam_num,gamma)
    rate_num = sum(R>0,2);
    [~,idx] = sort(rate_num,'descend');
    row = size(R,1);
    
    rated_set = [];
    sel = zeros(row,1);
 
    tag = 0;
    
    % need confirmed next step, sam_num > 0
    for i = 1:row
        rate_idx = find( R(idx(i),:) >0 );

        if (length(union(rated_set,rate_idx)) > length(rated_set) ) ...
                && (tag == gamma)
            sel(i) = 1;
            rated_set = union(rated_set,rate_idx);
            tag = 0;
            sam_num = sam_num - 1;          
        elseif tag < gamma
            sel(i) = 1;
            rated_set = union(rated_set,rate_idx);
            sam_num = sam_num - 1;          
            tag = tag + 1;
        end

        if sam_num ==0
           sam_user  = idx(sel>0);
           pri_user = idx(sel==0);
           return;
        end    
    end

    sam_user  = idx(sel>0);
    pri_user = idx(sel==0);
end
