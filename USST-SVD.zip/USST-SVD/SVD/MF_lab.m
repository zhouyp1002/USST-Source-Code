% Program for calculating the RMSE of MF method (including differential 
% privacy version),tested on Matlab (R2017b)
%-------------------------------------------------------------------------
% Input: dataset_name is the name of the dataset, b is the parameter b of
% lapalace noise(option)
% Output: the RMSE , ori is the original score , pred is the score predicted

function [RMSE,ori,pred]  = MF_lab(dataset_name,b)
    %��ȡѵ�����Ͳ��Լ�
    file_train_path = strcat('../data/',dataset_name , '_train.txt');
    file_test_path = strcat('../data/',dataset_name , '_test.txt') ;
    file_train =  textread(file_train_path);
    file_test =  textread(file_test_path);
    test_set = file_test(:,1:3);
    train_set = file_train(:,1:3);     
   
    if ~exist('b','var')
        b = 0;
    end  
    
    if b ~= 0
        %B = 2;     
        % give noise to train_set
        noise =  Lap(b,size(train_set,1),1);
        train_set(:,3) = train_set(:,3) + noise;
    end
    
    
    sample_num = size(test_set,1);
    ori = zeros(1,sample_num);
    pred = zeros(1,sample_num);

    row = max(  max(train_set(:,1)),max(test_set(:,1)) );
    col = max(  max(train_set(:,2)),max(test_set(:,2)) );
    [P,Q,miu,b_user,b_item] = SGD_MF(train_set,row,col);   
   
    %test and get the measurement result
    disp(['��������:  ',num2str( sample_num )]);
    for i = 1:sample_num
        if mod(i,5000) == 0
            %disp(['MF���Խ���:  ',num2str( floor(i* 100/sample_num) ),'%']);
        end
        
        user = test_set(i,1);
        item = test_set(i,2);
        ori_score = test_set(i,3);       
        pred_MF_score =  P(user,:)*Q(:,item) + miu + b_user(user)+b_item(item);
              
        if pred_MF_score > 5
            pred_MF_score = 5;
        elseif pred_MF_score < 1
            pred_MF_score = 1;
        end
               
        ori(i) = ori_score;
        pred(i) = pred_MF_score;        
    end

    RMSE  = sqrt((ori-pred)*(ori-pred)'/sample_num);     
end


% lapalace noise generator
function [res] = sign(x)
    x(x<0) = -1;
    x(x>=0) = 1;
    res = x;
end

function [res] =  Uniform(bias,row,col)
    if ~exist('row','var')
        row = 1;
    end
    
    if ~exist('col','var')
        col = 1;
    end
        
    % rand --  Uniformly distributed random numbers  0~1
    res =  bias + rand(row,col);
end
 

% more lambda, more wide distribute , ie. more noise
function [res] =  Lap(lambda,row,col,miu)
    if ~exist('row','var')
        row = 1;
    end
    
    if ~exist('col','var')
        col = 1;
    end
    
    if ~exist('miu','var')
        miu = 0;
    end

    U = Uniform(-0.5,row,col) ;
    % log  -- e
    res = miu - lambda * sign(U) .* log( 1 - 2*abs(U) ) ;
end


