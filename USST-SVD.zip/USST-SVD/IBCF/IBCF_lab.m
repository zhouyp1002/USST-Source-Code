% Program for calculating the RMSE of IBCF method ,tested on Matlab (R2017b)
%-------------------------------------------------------------------------
% Input:  dataset_name is the name of the dataset
% Output: the RMSE 

function [RMSE,ori,pred]  = IBCF_lab(dataset_name)
    disp('IBCF ����ִ��...');
    %��ȡѵ�����Ͳ��Լ�
    file_train_path = strcat('../data/',dataset_name , '_train.txt');
    file_test_path = strcat('../data/',dataset_name , '_test.txt') ;
    file_train =  textread(file_train_path);
    file_test =  textread(file_test_path);
    test_set = file_test(:,1:3);
    train_set = file_train(:,1:3);          %��ȡuser-item-rating��Ԫ��
 
    sample_num = size(test_set,1);
    ori = zeros(1,sample_num);
    pred = zeros(1,sample_num);

    %����Ԫ����ʽ�ؽ�������ʽ
    m =  max(  max(train_set(:,1)),max(test_set(:,1)) ); %user����
    n =  max(  max(train_set(:,2)),max(test_set(:,2)) ); %item����
    %{
    R = zeros(m,n);
    for cnt = 1:num
       user = trainset(cnt,1);
       item = trainset(cnt,2);
       score = trainset(cnt,3);
       R(user,item) = score;
    end
    %}
    A = sparse(file_train(:,1),file_train(:,2),file_train(:,3),m,n);
    R = full(A);
    
    %test and get the measurement result
    sample_num = sample_num ;
    disp(['��������:  ',num2str( sample_num )]);
    for i = 1:sample_num
        if mod(i,1000) == 0
            disp(['IBCF���Խ���:  ',num2str( floor(i* 100/sample_num) ),'%']);
        end
        
        user = test_set(i,1);
        item = test_set(i,2);
        
        ori_score = test_set(i,3);       
        pred_IBCF_score = PP_IBCF(R,user,item);
        
        ori(i) = ori_score;
        pred(i) = pred_IBCF_score;        
    end

    RMSE  = sqrt((ori-pred)*(ori-pred)'/sample_num);  
    
    disp(['RMSE:  ',num2str(RMSE)]);
    disp('�������');
end
