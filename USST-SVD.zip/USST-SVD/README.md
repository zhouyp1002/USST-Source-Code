This code is written in Matlab.

`./data`  stores the dataset of MovieLens and Netflix (10,000 users and 2,000 items). 

`split_data.m` is used to split the dataset into train set, test set and validation set. The results are stored in `./data`

In the Path of `./SVD`

- `MF_lab.m`  is a module of SVD method. This module can accept an argument `b`, which denotes the scaling parameter in Laplace noise when applying differential privacy. 
- `PPRS.m` is a module of our USST-SVD method. It can accept arguments to specify the sampling method and sampling ratio. 

- `SP.m` is a module of the selective Privacy Naive method, which is named **NMBP** in our paper.

- `user_sample.m` returns the sampled users, given the sampling method and sampling number.

- `SGD_MF.m` is the detailed MF sub-module, which is called by other algorithms. 

- `native_ucla.m` is a auxliary module for ` SP.m`

`./IBCF/IBCF_lab.m`  is a module of the item-based collaborative filtering method, which is named **PPIBCF** in our paper.

`lab1.m  ` runs the SVD,  USST-SVD-Rnd, USST-SVD-UB, NMBP, PPIBCF algorithm. The result is displayed in Figure 2 in the paper.

` lab2.m ` runs our method with all kinds of sample methods under various sample ratios. The result is displayed in Figure 4 in the paper.