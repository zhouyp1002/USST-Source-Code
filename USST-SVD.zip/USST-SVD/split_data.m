function [RMSE] = split_data(dataset_name)

    if ~exist('dataset_name','var')
        dataset_name = 'ml_100k';
    end
    
    % read file
    read_path = strcat('./data/',dataset_name , '.txt');  
    file =  textread(read_path); 
    file = file(:,1:3);

    % split train and test , and fixed 
    %��1��4�ı����������ѵ�����Ͳ��Լ�
    ratio = 0.8;
    num = size(file,1);
    rand_idx = randperm(num);    
    train_idx = rand_idx(1:floor(ratio*num));
    test_idx = rand_idx(floor(ratio*num)+1:num);
    train_set =file(train_idx,:);
    test_set = file(test_idx,:);

    % write to file
    write_path_train = strcat('./data/',dataset_name , '_train.txt');
    write_path_test = strcat('./data/',dataset_name , '_test.txt');
    dlmwrite(write_path_train,train_set,'\t');
    dlmwrite(write_path_test,test_set,'\t');
end
