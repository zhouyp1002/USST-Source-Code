import os
import numpy as np
import subprocess

test_num = 5
epsilon_list = [0.1,0.2,0.4,0.8,1.6,3.2,6.4]
dataset = 'ml-1m'

for it in range(5,10):
#for it in range(test_num):
    for epsilon in epsilon_list:

    	#python -u NeuMF.py --dataset ml-1m --epochs 20 --batch_size 256 --num_factors 8 --layers [64,32,16,8] --reg_mf 0 --reg_layers [0,0,0,0] --num_neg 4 --lr 0.001 --learner adam --verbose 1 --out 0 

        command = 'python -u NeuMF.py --dataset %s --epochs 20 --batch_size 256 \
        --num_factors 8 --layers [64,32,16,8] --reg_mf 0 --reg_layers [0,0,0,0] --num_neg 4 --lr 0.001 --learner adam --verbose 1 --out 0 \
        --epsilon %.2f'%(dataset,epsilon)
        command = 'nohup %s >log_%d_%d.txt 2>&1 &'%(command,it,int(epsilon*10))

        print('command:',command)

        p = subprocess.Popen(command,shell=True)
        #p.wait()
        
        #p = os.popen(command)


       