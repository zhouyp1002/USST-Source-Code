import os
import numpy as np
import subprocess

#print("hello")
#p = subprocess.call('ls > log.txt',shell=True)
#p = os.popen('ls')
#print(p.read())
#p.close()
'''
p = subprocess.Popen('ping -c 4 baidu.com',shell = True)
p.wait()
print('finish_1')
p = subprocess.Popen('ping -c 4 www.tsinghua.edu.cn',shell = True)
p.wait()
print('finish_2')
'''


#sample_method = ['random','user_base','item_base','mixed']
sample_method = ['user_base']
sample_rate = np.linspace(0.02,0.2,10)
#print(sample_rate)

dataset = 'ml-1m'


'''
command_1 = 'python GMF.py --dataset %s --epochs 20 --batch_size 256 \
        --num_factors 8 --regs [0,0] --num_neg 4 --lr 0.001 --learner adam --verbose 1 --out 1'%(dataset)
command = 'nohup %s >log.txt &'%command_1
#print(command)
#p = subprocess.call(command,shell=True)
print(command)

# mistake
command_2 = 'python MLP.py --dataset %s --epochs 20 --batch_size 256 \
--num_factors 8 --regs [0,0] --num_neg 4 --lr 0.001 --learner adam --verbose 1 --out 1'%(dataset)
command = 'nohup %s >log.txt &'%command_2
#p = subprocess.call(command,shell=True)
print(command)

#mistake
command_3 = 'python NeuMF.py --dataset %s --epochs 20 --batch_size 256 \
--num_factors 8 --regs [0,0] --num_neg 4 --lr 0.001 --learner adam --verbose 1 --out 1 '%(dataset)
command = 'nohup %s >log.txt &'%command_3
#p = subprocess.call(command,shell=True)
print(command)
'''

'''
nohup python lab.py >log.txt 2>&1 &
'''

'''
command_1 = 'python GMF_private.py --dataset %s --epochs 20 --batch_size 256 \
        --num_factors 8 --regs [0,0] --num_neg 4 --lr 0.001 --learner adam --verbose 1 --out 1 \
        --sample_method %s --sample_rate %.2f --gamma 5'%(dataset,sample_method[0],sample_rate[0])
        #command = 'nohup %s >log.txt 2>&1 &'%command_1
command = command_1
print('command:',command)
p = subprocess.Popen(command,shell=True)
p.wait()

'''
for rate in sample_rate:
    for method in sample_method:

    	#python NeuMF_private.py --dataset ml-1m --epochs 3 --batch_size 256 --num_factors 8 --layers [64,32,16,8] --reg_mf 0 --reg_layers [0,0,0,0] --num_neg 4 --lr 0.001 --learner adam --verbose 1 --out 1


        command_4 = 'python NeuMF_private.py --dataset %s --epochs 20 --batch_size 256 \
        --num_factors 8 --layers [64,32,16,8] --reg_mf 0 --reg_layers [0,0,0,0] --num_neg 4 --lr 0.001 --learner adam --verbose 1 --out 1 \
        --sample_method %s --sample_rate %.2f --gamma 5'%(dataset,method,rate)
        #command = 'nohup %s >>log.txt 2>&1 &'%command_1
        command = 'nohup %s >log_%d_%s.txt 2>&1 &'%(command_4,int(rate*100),method)
        #command = 'nohup %s >log.txt 2>&1 &'%(command_4)
        #command = command_4
        print('command:',command)
        #p = subprocess.Popen(command,shell=True)
        #p.wait()
        
        #p = os.popen(command)


        '''
        command_1 = 'python GMF_private.py --dataset %s --epochs 20 --batch_size 256 \
        --num_factors 8 --regs [0,0] --num_neg 4 --lr 0.001 --learner adam --verbose 1 --out 1 \
        --sample_method %s --sample_rate %.2f --gamma 5'%(dataset,method,rate)
        #command = 'nohup %s >>log.txt 2>&1 &'%command_1
        command = 'nohup %s >>log.txt 2>&1 '%command_1
        #command = command_1
        print('command:',command)
        p = subprocess.Popen(command,shell=True)
        p.wait()
        #p = os.popen(command)


        command_2 = 'python MLP_private.py --dataset %s --epochs 20 --batch_size 256 \
        --layers [64,32,16,8] --reg_layers [0,0,0,0] --num_neg 4 --lr 0.001 --learner adam --verbose 1 --out 1 \
        --sample_method %s --sample_rate %.2f --gamma 5'%(dataset,method,rate)
        #command = 'nohup %s >>log.txt 2>&1 &'%command_2
        command = 'nohup %s >>log.txt 2>&1 '%command_2
        #command = command_2
        print('command:',command)
        p = subprocess.Popen(command,shell=True)
        p.wait()
        #p = os.popen(command)


        command_3 = 'python NeuMF_private.py --dataset %s --epochs 20 --batch_size 256 \
        --num_factors 8 --layers [64,32,16,8] --num_neg 4 --lr 0.001 --learner adam --verbose 1 --out 1 \
        --mf_pretrain Pretrain/%s_GMF_8_1.h5 --mlp_pretrain Pretrain/%s_MLP_[64,32,16,8]_1.h5  \
        --sample_method %s --sample_rate %.2f --gamma 5'%(dataset,dataset,dataset,method,rate)
        #command = 'nohup %s >>log.txt 2>&1 &'%command_3
        command = 'nohup %s >>log.txt 2>&1 '%command_3
        #command = command_3
        print('command:',command)
        p = subprocess.Popen(command,shell=True)
        p.wait()
        #p = os.popen(command)
        '''
