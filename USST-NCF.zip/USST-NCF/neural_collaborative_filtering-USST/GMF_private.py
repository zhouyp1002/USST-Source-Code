import numpy as np
import random
import theano.tensor as T
import keras
from keras import backend as K
from keras import initializations
from keras.models import Sequential, Model, load_model, save_model
from keras.layers.core import Dense, Lambda, Activation
from keras.layers import Embedding, Input, Dense, merge, Reshape, Merge, Flatten
from keras.optimizers import Adagrad, Adam, SGD, RMSprop
from keras.regularizers import l2
from Dataset import Dataset
from evaluate import evaluate_model
from time import time
import multiprocessing as mp
import GMF, MLP
import sys
import math
import argparse

#################### Arguments ####################
def parse_args():
    parser = argparse.ArgumentParser(description="Run GMF.")
    parser.add_argument('--path', nargs='?', default='Data/',
                        help='Input data path.')
    parser.add_argument('--dataset', nargs='?', default='ml-1m',
                        help='Choose a dataset.')
    parser.add_argument('--epochs', type=int, default=100,
                        help='Number of epochs.')
    parser.add_argument('--batch_size', type=int, default=256,
                        help='Batch size.')
    parser.add_argument('--num_factors', type=int, default=8,
                        help='Embedding size.')
    parser.add_argument('--regs', nargs='?', default='[0,0]',
                        help="Regularization for user and item embeddings.")
    parser.add_argument('--num_neg', type=int, default=4,
                        help='Number of negative instances to pair with a positive instance.')
    parser.add_argument('--lr', type=float, default=0.001,
                        help='Learning rate.')
    parser.add_argument('--learner', nargs='?', default='adam',
                        help='Specify an optimizer: adagrad, adam, rmsprop, sgd')
    parser.add_argument('--verbose', type=int, default=1,
                        help='Show performance per X iterations')
    parser.add_argument('--out', type=int, default=1,
                        help='Whether to save the trained model.')

    #add by Liu
    parser.add_argument('--sample_method', nargs='?', default='user_base',
                        help='Choose a sample method: user_base, random, item_base, mixed')
    parser.add_argument('--sample_rate', type=float, default=0.2,
                        help='sample rate')
    parser.add_argument('--gamma', type=int, default=5,
                        help='the gamma parameter in mixed sample method')

    return parser.parse_args()

def init_normal(shape, name=None):
    return initializations.normal(shape, scale=0.01, name=name)

def get_model_public(num_users, num_items, latent_dim, regs=[0,0]):
    # Input variables
    user_input = Input(shape=(1,), dtype='int32', name = 'user_input')
    item_input = Input(shape=(1,), dtype='int32', name = 'item_input')

    MF_Embedding_User = Embedding(input_dim = num_users, output_dim = latent_dim, name = 'user_embedding',
                                  init = init_normal, W_regularizer = l2(regs[0]), input_length=1)
    MF_Embedding_Item = Embedding(input_dim = num_items, output_dim = latent_dim, name = 'item_embedding',
                                  init = init_normal, W_regularizer = l2(regs[1]), input_length=1)   
    
    # Crucial to flatten an embedding vector!
    user_latent = Flatten()(MF_Embedding_User(user_input))
    item_latent = Flatten()(MF_Embedding_Item(item_input))
    
    # Element-wise product of user and item embeddings 
    predict_vector = merge([user_latent, item_latent], mode = 'mul')
    
    # Final prediction layer
    #prediction = Lambda(lambda x: K.sigmoid(K.sum(x)), output_shape=(1,))(predict_vector)
    prediction = Dense(1, activation='sigmoid', init='lecun_uniform', name = 'prediction')(predict_vector)
    
    model = Model(input=[user_input, item_input], 
                output=prediction)

    return model

def get_model(num_users, num_items, latent_dim, regs=[0,0]):
    # Input variables
    user_input = Input(shape=(1,), dtype='int32', name = 'user_input')
    item_input = Input(shape=(1,), dtype='int32', name = 'item_input')

    MF_Embedding_User = Embedding(input_dim = num_users, output_dim = latent_dim, name = 'user_embedding',
                                  init = init_normal, W_regularizer = l2(regs[0]), input_length=1)
    MF_Embedding_Item = Embedding(input_dim = num_items, output_dim = latent_dim, name = 'item_embedding',
                                  init = init_normal, W_regularizer = l2(regs[1]), input_length=1,trainable=False)   
    
    # Crucial to flatten an embedding vector!
    user_latent = Flatten()(MF_Embedding_User(user_input))
    item_latent = Flatten()(MF_Embedding_Item(item_input))
    
    # Element-wise product of user and item embeddings 
    predict_vector = merge([user_latent, item_latent], mode = 'mul')
    
    # Final prediction layer
    #prediction = Lambda(lambda x: K.sigmoid(K.sum(x)), output_shape=(1,))(predict_vector)
    prediction = Dense(1, activation='sigmoid', init='lecun_uniform', name = 'prediction',trainable=False)(predict_vector)
    
    model = Model(input=[user_input, item_input], 
                output=prediction)


    gmf_model = GMF.get_model(num_users,num_items,latent_dim)
    mf_pretrain = 'Pretrain/ml-1m_GMF_8_1.h5'
    gmf_model.load_weights(mf_pretrain)
    gmf_user_embeddings = gmf_model.get_layer('user_embedding').get_weights()
    gmf_item_embeddings = gmf_model.get_layer('item_embedding').get_weights()
    model.get_layer('user_embedding').set_weights(gmf_user_embeddings)
    model.get_layer('item_embedding').set_weights(gmf_item_embeddings)
    gmf_prediction = gmf_model.get_layer('prediction').get_weights()
    model.get_layer('prediction').set_weights(gmf_prediction)    

    return model


# when use this funciton ,need to check Dataset.py ,about the setting of  user_record_item_dict
def get_public_user_list(train,sample_method='user_base',sample_rate=0.2,\
	user_record_num=np.array([]), user_record_item_dict = dict(), gamma=5):

    public_user = []
    user_num = train.shape[0]
    sample_num = int(np.floor(user_num*sample_rate))

    if sample_method == 'user_base':
        public_user = np.argsort(-user_record_num)[:sample_num+1]


    elif sample_method == 'item_base':
        # sort
        user_list_item_order = np.zeros(user_num+1)
        for u in user_record_item_dict.keys():
        	user_list_item_order[u] = len(user_record_item_dict[u])
        user_list_item_order = np.argsort(-user_list_item_order)[:-1] # delete the 0th user

        item_cover_set = set()

        #first loop, add and check union & size
        for user in user_list_item_order:
            probe_set = set(user_record_item_dict[user])
            if len(item_cover_set) < len(item_cover_set | probe_set):
                item_cover_set = item_cover_set | probe_set
                public_user.append(user)
                if len(public_user) == sample_num:
                    return public_user

        #second loop, fill up
        for user in user_list_item_order:     
            if user not in public_user:
                public_user.append(user)
                if len(public_user) == sample_num:
                    return public_user


    elif sample_method == 'random':
        temp = np.array(range(user_num)) + 1
        random.shuffle(temp)
        public_user = temp[:sample_num+1]


    elif sample_method == 'mixed':
    	# sort
        user_list_item_order = np.zeros(user_num+1)
        for u in user_record_item_dict.keys():
        	user_list_item_order[u] = len(user_record_item_dict[u])
        user_list_item_order = np.argsort(-user_list_item_order)[:-1] # delete the 0th user

        item_cover_set = set()


        tag = 0

        for user in user_list_item_order:
            probe_set = set(user_record_item_dict[user])

            if tag < gamma:
                tag += 1
                item_cover_set = item_cover_set | probe_set
                public_user.append(user)
            else:
                # tag == gamma
                tag = 0
                if len(item_cover_set) < len(item_cover_set | probe_set):
                    item_cover_set = item_cover_set | probe_set
                    public_user.append(user)
            
            if len(public_user) == sample_num:
                    return public_user
        
        # if the gamma is set too samll, the number of sample user may not reach sample_num and will reach here

    return public_user



def get_train_instances_public(train, num_negatives,sample_user_list,num_items):
    user_input, item_input, labels = [],[],[]
    num_users = train.shape[0]
    for (u, i) in train.keys():
        if u not in sample_user_list:
        	continue

        # positive instance
        user_input.append(u)
        item_input.append(i)
        labels.append(1)

        # negative instances
        for t in xrange(num_negatives):
            j = np.random.randint(num_items)
            while train.has_key((u, j)):
                j = np.random.randint(num_items)
            user_input.append(u)
            item_input.append(j)
            labels.append(0)


    return user_input, item_input, labels

def get_train_instances_private(train, num_negatives,sample_user_list,num_items):
    user_input, item_input, labels = [],[],[]
    num_users = train.shape[0]
    for (u, i) in train.keys():
        if u in sample_user_list:
        	continue

        # positive instance
        user_input.append(u)
        item_input.append(i)
        labels.append(1)
        # negative instances
        for t in xrange(num_negatives):
            j = np.random.randint(num_items)
            while train.has_key((u, j)):
                j = np.random.randint(num_items)
            user_input.append(u)
            item_input.append(j)
            labels.append(0)
    return user_input, item_input, labels


def get_test_for_public(testRatings, testNegatives, sample_user_list):
    testRatings_public = []
    testNegatives_public = []

    for rate,neg in zip(testRatings,testNegatives):
        if rate[0] in sample_user_list:
            testRatings_public.append(rate)
            testNegatives_public.append(neg)
    
    return testRatings_public,testNegatives_public


if __name__ == '__main__':
    args = parse_args()
    num_factors = args.num_factors
    regs = eval(args.regs)
    num_negatives = args.num_neg
    learner = args.learner
    learning_rate = args.lr
    epochs = args.epochs
    batch_size = args.batch_size
    verbose = args.verbose

    #add by Liu
    sample_method = args.sample_method
    sample_rate = args.sample_rate
    gamma = args.gamma
    
    topK = 10
    evaluation_threads = 1 #mp.cpu_count()
    print("GMF arguments: %s" %(args))
    model_out_file = 'Pretrain/%s_GMF_%d_%d.h5' %(args.dataset, num_factors, 1)
    model_out_file_2 = 'Pretrain/%s_GMF_%d_%d.h5' %(args.dataset, num_factors, 2)  

    # Loading data
    t1 = time()
    dataset = Dataset(args.path + args.dataset)
    train, testRatings, testNegatives = dataset.trainMatrix, dataset.testRatings, dataset.testNegatives
    num_users, num_items = train.shape
    print("Load data done [%.1f s]. #user=%d, #item=%d, #train=%d, #test=%d" 
          %(time()-t1, num_users, num_items, train.nnz, len(testRatings)))
    
    # Build model
    model_public = get_model_public(num_users, num_items, num_factors, regs)

    if learner.lower() == "adagrad": 
        model_public.compile(optimizer=Adagrad(lr=learning_rate), loss='binary_crossentropy')
    elif learner.lower() == "rmsprop":
        model_public.compile(optimizer=RMSprop(lr=learning_rate), loss='binary_crossentropy')
    elif learner.lower() == "adam":
        model_public.compile(optimizer=Adam(lr=learning_rate), loss='binary_crossentropy')
    else:
        model_public.compile(optimizer=SGD(lr=learning_rate), loss='binary_crossentropy')
    #print(model.summary())
    
    # Init performance
    t1 = time()
    (hits, ndcgs) = evaluate_model(model_public, testRatings, testNegatives, topK, evaluation_threads)
    hr, ndcg = np.array(hits).mean(), np.array(ndcgs).mean()
    #mf_embedding_norm = np.linalg.norm(model.get_layer('user_embedding').get_weights())+np.linalg.norm(model.get_layer('item_embedding').get_weights())
    #p_norm = np.linalg.norm(model.get_layer('prediction').get_weights()[0])
    print('Init: HR = %.4f, NDCG = %.4f\t [%.1f s]' % (hr, ndcg, time()-t1))


    t1 = time()
    user_record_num_list = dataset.user_record_num_list
    user_record_item_dict = dataset.user_record_item_dict
    #print(user_record_num_list) #for debug
    
    public_user =  get_public_user_list(train,sample_method=sample_method,sample_rate=sample_rate,\
	user_record_num=user_record_num_list, user_record_item_dict = user_record_item_dict, gamma=gamma)
    #public_user = get_public_user_list(train,user_record_num=user_record_num_list,\
    #	user_record_item_dict = user_record_item_dict,sample_method=sample_method)
    print('Sample public user: rate = %.2f, method = %s\t [%.1f s]' % (sample_rate, sample_method, time()-t1)) #
    print('debug: public number %d' % len(public_user)) #debug
    #print('debug: public user', public_user) #debug


    # ------------------------------------------------------------------------------------

    # Train model
    best_hr, best_ndcg, best_iter = hr, ndcg, -1

    testRatings_public,testNegatives_public = get_test_for_public(testRatings, testNegatives, public_user)

    for epoch in xrange(epochs):
        t1 = time()
        # Generate training instances
        user_input, item_input, labels = get_train_instances_public(train, num_negatives,public_user,num_items)

        #print('debug: load  train_instances_public  [%.1f s]' % (time()-t1)) #debug
        
        # Training
        hist = model_public.fit([np.array(user_input), np.array(item_input)], #input
                         np.array(labels), # labels 
                         batch_size=batch_size, nb_epoch=1, verbose=0, shuffle=True)
        t2 = time()
        
        # Evaluation
        if epoch %verbose == 0:
            (hits, ndcgs) = evaluate_model(model_public, testRatings_public, testNegatives_public, topK, evaluation_threads)
            hr, ndcg, loss = np.array(hits).mean(), np.array(ndcgs).mean(), hist.history['loss'][0]
            print('Iteration %d [%.1f s]: HR = %.4f, NDCG = %.4f, loss = %.4f [%.1f s]' 
                  % (epoch,  t2-t1, hr, ndcg, loss, time()-t2))
            if hr > best_hr:
                best_hr, best_ndcg, best_iter = hr, ndcg, epoch
                if args.out > 0:
                    model_public.save_weights(model_out_file, overwrite=True)

    print("End. Best Iteration %d:  HR = %.4f, NDCG = %.4f. " %(best_iter, best_hr, best_ndcg))
    if args.out > 0:
        print("The best public GMF model is saved to %s" %(model_out_file))


    # ------------------------------------------------------------------------


    # Build model
    model_private = get_model(num_users, num_items, num_factors, regs)

    if learner.lower() == "adagrad": 
        model_private.compile(optimizer=Adagrad(lr=learning_rate), loss='binary_crossentropy')
    elif learner.lower() == "rmsprop":
        model_private.compile(optimizer=RMSprop(lr=learning_rate), loss='binary_crossentropy')
    elif learner.lower() == "adam":
        model_private.compile(optimizer=Adam(lr=learning_rate), loss='binary_crossentropy')
    else:
        model_private.compile(optimizer=SGD(lr=learning_rate), loss='binary_crossentropy')
    #print(model.summary())
    
    # Init performance
    t1 = time()
    (hits, ndcgs) = evaluate_model(model_private, testRatings, testNegatives, topK, evaluation_threads)
    hr, ndcg = np.array(hits).mean(), np.array(ndcgs).mean()
    #mf_embedding_norm = np.linalg.norm(model.get_layer('user_embedding').get_weights())+np.linalg.norm(model.get_layer('item_embedding').get_weights())
    #p_norm = np.linalg.norm(model.get_layer('prediction').get_weights()[0])
    print('Init: HR = %.4f, NDCG = %.4f\t [%.1f s]' % (hr, ndcg, time()-t1))

    # Train model
    best_hr, best_ndcg, best_iter = hr, ndcg, -1
    for epoch in xrange(epochs):
        t1 = time()
        # Generate training instances
        user_input, item_input, labels = get_train_instances_private(train, num_negatives,public_user,num_items)
        
        # Training
        hist = model_private.fit([np.array(user_input), np.array(item_input)], #input
                         np.array(labels), # labels 
                         batch_size=batch_size, nb_epoch=1, verbose=0, shuffle=True)
        t2 = time()
        
        # Evaluation
        if epoch %verbose == 0:
            (hits, ndcgs) = evaluate_model(model_private, testRatings, testNegatives, topK, evaluation_threads)
            hr, ndcg, loss = np.array(hits).mean(), np.array(ndcgs).mean(), hist.history['loss'][0]
            print('Iteration %d [%.1f s]: HR = %.4f, NDCG = %.4f, loss = %.4f [%.1f s]' 
                  % (epoch,  t2-t1, hr, ndcg, loss, time()-t2))
            if hr > best_hr:
                best_hr, best_ndcg, best_iter = hr, ndcg, epoch
                if args.out > 0:
                    model_private.save_weights(model_out_file_2, overwrite=True)

    print("End. Best Iteration %d:  HR = %.4f, NDCG = %.4f. " %(best_iter, best_hr, best_ndcg))
    if args.out > 0:
        print("The best privte GMF model is saved to %s" %(model_out_file_2))
