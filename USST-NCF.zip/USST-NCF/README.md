`./neural_collaborative_filtering-USST` is a module of our USST-NCF method. We modify the open-source code of **NCF** and generate these files. 

`GMF_private.py MLP_private.py NeuMF_private.py` are modified versions based on the original `GMF.py, MLP.py, NeuMF.py` files, respectively. The modifications include user sampling, training on public data and distribution to private users.

`lab.py` is the main file. The result is displayed in Figure 6 in the paper.

For running the original NCF code, please refer to `README_NCF_paper.md`.

